<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Usuarios</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Js Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Estilos propios -->
    <link rel="stylesheet" href="<?= base_url('/public/css/styles.css') ?>">
</head>

<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between mb-3">
            <a href="<?= site_url('/menu') ?>" class="btn btn-secondary">Volver al Menú</a>
            <a href="<?= site_url('usuarios/create') ?>" class="btn btn-secondary">Agregar Usuario</a>
        </div>

        <div class="card p-4">
            <h1 class="text-center mb-4">Lista de Usuarios</h1>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Apellido</th>
                            <th scope="col">Usuario</th>
                            <th scope="col">Contraseña</th>
                            <th scope="col" class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $usuario) : ?>
                            <tr>
                                <td><?= esc($usuario['nombre']); ?></td>
                                <td><?= esc($usuario['apellido']); ?></td>
                                <td><?= esc($usuario['usuario']); ?></td>
                                <td><?= esc($usuario['pass']); ?></td>
                                <td class="text-center">
                                    <a href="<?= site_url('usuarios/edit/' . $usuario['id']) ?>" class="btn btn-primary btn-sm">Editar</a>
                                    <a href="<?= site_url('usuarios/delete/' . $usuario['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Seguro que desea eliminar?')">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="mt-5 text-center bg-dark text-white fw-bold py-3">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>