<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Membresías</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="<?= base_url('/public/css/styles.css') ?>">
</head>

<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between flex-wrap mb-3">
            <a href="<?= site_url('/menu') ?>" class="btn btn-secondary mb-2">Volver al Menú</a>
            <a href="<?= site_url('membresias/create') ?>" class="btn btn-secondary mb-2">Agregar nueva membresía</a>
            <a href="<?= site_url('membresias/descuento_clases') ?>" class="btn btn-secondary mb-2">Descontar Clases</a>
        </div>
        <div class="card p-4">
            <h1 class="text-center mb-4">Listado de Membresías</h1>

            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Tipo de Actividad</th>
                            <th scope="col">DNI Alumno</th>
                            <th scope="col">Precio</th>
                            <th scope="col">Clases</th>
                            <th scope="col">Fecha Alta</th>
                            <th scope="col">Fecha Baja</th>
                            <th scope="col">Turno</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead> 
                    <tbody>
                        <?php foreach ($membresias as $membresia): ?>
                            <tr>
                                <td><?= esc($membresia['tipo_nombre']); ?></td>
                                <td><?= esc($membresia['alumno_dni']); ?></td>
                                <td><?= esc($membresia['precio']); ?></td>
                                <td><?= esc($membresia['clases']); ?></td>
                                <td><?= date('d-m-Y', strtotime($membresia['fecha_alta'])); ?></td>
                                <td><?= date('d-m-Y', strtotime($membresia['fecha_baja'])); ?></td>
                                <td><?= esc($membresia['turno_horario']); ?></td>
                                <td><?= esc($membresia['estado']); ?></td>
                                <td>
                                    <a href="<?= site_url('membresias/edit/' . $membresia['id']) ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                                    <a href="<?= site_url('membresias/delete/' . $membresia['id']) ?>" class="btn btn-danger btn-sm mb-1" onclick="return confirm('¿Está seguro de que desea eliminar esta membresía?')">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <footer class="mt-5 text-center bg-dark text-white fw-bold py-3">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>
