<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Descontar Clase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="<?= base_url('/public/css/menu.css') ?>">
    <style>
        body {
            background-color: #343a40;
            /* Fondo oscuro para mejor contraste */
        }

        .container {
            max-width: 600px;
            /* Ancho máximo para dispositivos más grandes */
        }

        h1 {
            font-size: 2.5rem;
            /* Tamaño de fuente más grande */
        }

        .form-label {
            font-size: 1.2rem;
            /* Tamaño de fuente para etiquetas más grande */
        }

        .btn {
            font-size: 1.2rem;
            /* Tamaño de fuente de los botones más grande */
            padding: 10px 20px;
            /* Espaciado interno más grande */
        }

        footer {
            padding: 15px 0;
            /* Espaciado en el pie de página */
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4 text-white">Descontar Clase</h1>

        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success">
                <?= session()->getFlashdata('success') ?>
            </div>
        <?php endif; ?>

        <?php if (isset($validation)): ?>
            <div class="alert alert-danger">
                <?= $validation->listErrors() ?>
            </div>
        <?php endif; ?>

        <form action="<?= site_url('membresias/descontar_clase') ?>" method="post" class="d-flex flex-column align-items-center">
            <?= csrf_field() ?>

            <div class="mb-4 w-100">
                <label for="dni" class="form-label text-white">DNI del Alumno</label>
                <input type="text" name="dni" id="dni" class="form-control form-control-lg" required>
            </div>

            <div class="d-flex flex-column w-100">
                <button type="submit" class="btn btn-danger mb-2">Descontar Clase</button>
                <a href="<?= site_url('membresias') ?>" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
    </div>

    <footer class="mt-5" style="background-color: black; color: white; font-weight: bold; text-align: center;">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>