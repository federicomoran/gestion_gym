<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú</title>
    <!-- Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Js Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Estilos propios-->
    <link rel="stylesheet" href="<?= base_url('/public/css/menu.css') ?>">
    <style>
        .center-image {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 70vh;
            /* Ajusta la altura según sea necesario */
        }

        footer {
            background-color: black;
            color: white;
            font-weight: bold;
            text-align: center;
            padding: 10px;
            margin-top: 20px;
        }

        .navbar-brand,
        .nav-link {
            font-size: 1.2rem;
        }

        /* Ajustes para pantallas pequeñas */
        @media (max-width: 576px) {

            .navbar-brand,
            .nav-link {
                font-size: 1rem;
            }

            .dropdown-item {
                transition: background-color 0.3s ease, color 0.3s ease;
                /* Transición suave para el fondo y color */
                font-size: 1rem;
                /* Tamaño de texto fijo */
                cursor: pointer;
                /* Cursor tipo pointer para enlaces */
            }

            .dropdown-item:hover {
                background-color: #f0f0f0;
                /* Color de fondo más claro al hacer hover */
                color: #000;
                /* Asegura que el texto mantenga un buen contraste */
            }

            .dropdown-menu {
                border: none;
                /* Eliminar el borde del menú */
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                /* Añadir sombra suave */
            }

        }
    </style>
</head>

<body>
    <header>
        <!-- Inicio NavBar-->
        <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="<?= base_url('public/imagenes/a81.jpeg') ?>" alt="Logo" width="130" height="75">
                    Gimnasio A8
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <ul class="navbar-nav mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('alumnos') ?>">Alumnos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('instructores') ?>">Instructores</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('membresias') ?>">Membresias</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('turnos') ?>">Turnos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('tipo_actividad') ?>">Actividades</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('rutinas') ?>">Rutinas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= site_url('imc') ?>">IMC</a>
                        </li>
                        <!-- Mostrar el usuario logueado y el enlace de cerrar sesión -->
                        <?php if (session()->get('isLoggedIn')): ?>
                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                                    <span class="d-none d-lg-inline-flex" style="text-transform:capitalize"><?= session()->get('nombre') ?></span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                                    <a href="<?= site_url('usuarios') ?>" class="dropdown-item">Usuarios</a>
                                    <a href="<?= site_url('login/logout') ?>" class="dropdown-item">Cerrar Sesión</a>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Espaciado para evitar que el contenido esté oculto detrás del navbar fijo -->
        <div style="margin-top: 100px;"></div>

        <div class="center-image">
            <img src="<?= base_url('public/imagenes/a8.jpg') ?>" alt="Descripción de la imagen" class="img-fluid" style="width: 45%; max-width: 100%;">
        </div>

        <footer>
            Desarrollado por Facundo Simeoni y Federico Moran.
        </footer>
    </header>
</body>

</html>