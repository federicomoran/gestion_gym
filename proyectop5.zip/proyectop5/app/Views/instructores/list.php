<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Instructores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?= base_url('/public/css/styles.css') ?>">
</head>

<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between flex-wrap mb-3">
            <a href="<?= site_url('/menu') ?>" class="btn btn-secondary mb-2">Volver al Menú</a>
            <a href="<?= site_url('instructores/create') ?>" class="btn btn-secondary mb-2">Agregar nuevo instructor</a>
        </div>
        <div class="card p-4">
            <h1 class="text-center mb-4">Listado de Instructores</h1>

            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Apellido</th>
                            <th scope="col">Rutina</th>
                            <th scope="col">Teléfono</th>
                            <th scope="col">Correo</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($instructores as $instructor): ?>
                            <tr>
                                <td><?= esc($instructor['nombre']); ?></td>
                                <td><?= esc($instructor['apellido']); ?></td>
                                <td><?= esc($instructor['rutina_titulo']); ?></td>
                                <td><?= esc($instructor['telefono']); ?></td>
                                <td><?= esc($instructor['mail']); ?></td>
                                <td>
                                    <a href="<?= site_url('instructores/edit/' . $instructor['id']) ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                                    <a href="<?= site_url('instructores/delete/' . $instructor['id']) ?>" class="btn btn-danger btn-sm mb-1" onclick="return confirm('¿Está seguro de que desea eliminar este instructor?')">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <footer class="mt-5 text-center bg-dark text-white fw-bold py-3">
            Desarrollado por Facundo Simeoni y Federico Moran.
        </footer>
    </div>
</body>

</html>