<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rutinas</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Js Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Estilos propios -->
    <link rel="stylesheet" href="<?= base_url('/public/css/styles.css') ?>">
</head>

<body>
    <div class="container mt-5">
        <div class="d-flex flex-wrap justify-content-between mb-3">
            <a href="<?= site_url('/menu') ?>" class="btn btn-secondary mb-2">Volver al Menú</a>
            <a href="<?= site_url('rutinas/create') ?>" class="btn btn-secondary mb-2">Agregar nueva rutina personalizada</a>
            <a href="<?= site_url('rutinas/create_generico') ?>" class="btn btn-secondary mb-2">Agregar nueva rutina genérica</a>
            <a href="<?= site_url('rutinas/') ?>" class="btn btn-secondary mb-2">Listado de rutinas personalizadas</a>
        </div>
        <div class="card p-4">
            <h1 class="text-center mb-4">Lista de rutinas genéricas</h1>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Tipo de actividad</th>
                            <th scope="col">Título</th>
                            <th scope="col">Observaciones</th>
                            <th scope="col">Archivo</th>
                            <th scope="col" class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rutinas as $rutina) : ?>
                            <tr>
                                <td><?= esc($rutina['actividad_nombre']) ?></td>
                                <td><?= esc($rutina['titulo']) ?></td>
                                <td><?= esc($rutina['descripcion']) ?></td>
                                <td>
                                    <?php if ($rutina['archivo']): ?>
                                        <a href="<?= site_url('view/' . $rutina['archivo']) ?>" class="btn btn-info btn-sm" target="_blank">Ver/Descargar Archivo</a>
                                    <?php else: ?>
                                        Sin Archivo
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a href="<?= site_url('rutinas/edit_generico/' . $rutina['id']) ?>" class="btn btn-primary btn-sm mb-1">Editar</a>
                                    <a href="<?= site_url('rutinas/delete_generico/' . $rutina['id']) ?>" class="btn btn-danger btn-sm mb-1" onclick="return confirm('¿Seguro que desea eliminar?')">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="mt-5 text-center bg-dark text-white fw-bold py-3">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>