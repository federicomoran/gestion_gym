<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Turno</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Js Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Estilos propios-->
    <link rel="stylesheet" href="<?= base_url('/public/css/menu.css') ?>">
</head>

<body>
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card p-4" style="background-color: #343a40;">
            <h1 class="text-center mb-4 text-white">Editar Turno</h1>
            <form action="<?= site_url('turnos/update/' . $turno['id']) ?>" method="post" class="d-flex flex-column align-items-center">
                <?= csrf_field() ?>

                <div class="mb-3 w-100">
                    <label for="tipo_actividad" class="form-label text-white">Tipo de Actividad</label>
                    <select name="tipo_actividad" id="tipo_actividad" class="form-select">
                        <option value="0">Elija Actividad</option>
                        <?php foreach ($actividades as $actividad): ?>
                            <option value="<?= $actividad['id'] ?>" <?= $actividad['id'] == $turno['tipo_actividad'] ? 'selected' : '' ?>>
                                <?= esc($actividad['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3 w-100">
                    <label for="instructor" class="form-label text-white">Instructor</label>
                    <select name="instructor" id="instructor" class="form-select">
                        <option value="0">Elija Instructor</option>
                        <?php foreach ($instructores as $instructor): ?>
                            <option value="<?= $instructor['id'] ?>" <?= $instructor['id'] == $turno['instructor'] ? 'selected' : '' ?>>
                                <?= esc($instructor['nombre'] . ' ' . $instructor['apellido']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3 w-100">
                    <label for="horario" class="form-label text-white">Horario</label>
                    <input type="text" name="horario" id="horario" class="form-control" value="<?= esc($turno['horario']) ?>">
                </div>

                <div class="d-flex justify-content-between w-100">
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    <a href="<?= site_url('turnos') ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
    <br> <br> <br> <br> <br>
    <footer style="background-color: black; color: white; font-weight: bold; text-align: center;">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
    <br>
</body>

</html>