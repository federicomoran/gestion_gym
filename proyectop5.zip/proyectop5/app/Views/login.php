<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>| Gimnasio A8 |</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <!-- Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Js Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Estilos propios-->
    <link rel="stylesheet" href="<?= base_url('/public/css/styles.css') ?>">
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sign In Start --> 
        <div class="container-fluid">
            <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4">
                    <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3 shadow-lg">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <a href="" class="">
                                <img src="<?= base_url('public/imagenes/a8.jpg') ?>" alt="Logo" height="150px" width="300px">
                            </a>
                        </div>
                        <form action="<?= site_url('login/autenticar') ?>" method="post" class="d-flex flex-column align-items-center" enctype="multipart/form-data">
                            <?php if (session()->getFlashdata('error')): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?= session()->getFlashdata('error') ?>
                                </div>
                            <?php endif; ?>

                            <div class="form-floating mb-3 w-90">
                                <input type="text" class="form-control" name="usuario" id="floatingInput" placeholder="name@example.com" autocomplete="off" required>
                                <label for="floatingInput">Usuario</label>
                            </div>
                            <div class="form-floating mb-4 w-90">
                                <input type="password" class="form-control" name="pass" id="floatingPassword" placeholder="Password" required>
                                <label for="floatingPassword">Contraseña</label>
                            </div>
                            <button type="submit" class="btn btn-primary mr-2">Iniciar Sesión</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Sign In End -->
    </div>
</body>

</html>