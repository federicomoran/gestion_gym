<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar alumno</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Js Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Estilos propios-->
    <link rel="stylesheet" href="<?= base_url('/public/css/menu.css') ?>">
</head>

<body>
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card p-4" style="width: 400px; background-color: #343a40;">
            <h1 class="text-center mb-4 text-white">Editar alumno</h1>

            <!-- Flash message for errors -->
            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>

            <form action="<?= site_url('alumnos/update/' . $alumnos['id']) ?>" method="post" class="d-flex flex-column align-items-center">
                <div class="mb-3 w-100">
                    <label for="nombre" class="form-label text-white">Nombre</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" value="<?= esc($alumnos['nombre']) ?>" required>
                </div>
                <div class="mb-3 w-100">
                    <label for="apellido" class="form-label text-white">Apellido</label>
                    <input type="text" class="form-control" id="apellido" name="apellido" required value="<?= esc($alumnos['apellido']) ?>">
                </div>
                <div class="mb-3 w-100">
                    <label for="dni" class="form-label text-white">DNI</label>
                    <input type="text" class="form-control" id="dni" name="dni" required value="<?= esc($alumnos['dni']) ?>">
                </div>
                <div class="mb-3 w-100">
                    <label for="telefono" class="form-label text-white">Teléfono</label>
                    <input type="text" class="form-control" id="telefono" name="telefono" required value="<?= esc($alumnos['telefono']) ?>" pattern="[0-9]*" title="Por favor, ingrese solo números.">
                </div>
                <div class="mb-3 w-100">
                    <label for="direccion" class="form-label text-white">Dirección</label>
                    <input type="text" class="form-control" id="direccion" name="direccion" required value="<?= esc($alumnos['direccion']) ?>">
                </div>
                <div class="mb-3 w-100">
                    <label for="nacimiento" class="form-label text-white">Fecha de nacimiento</label>
                    <input type="date" class="form-control" id="nacimiento" name="nacimiento" required value="<?= esc($alumnos['nacimiento']) ?>">
                </div>
                <div class="mb-3 w-100">
                    <label for="correo" class="form-label text-white">Correo</label>
                    <input type="email" class="form-control" id="correo" name="correo" required value="<?= esc($alumnos['correo']) ?>">
                </div>
                <div class="mb-3 w-100">
                    <label for="fecha_registro" class="form-label text-white">Fecha de registro</label>
                    <input type="date" class="form-control" id="fecha_registro" name="fecha_registro" required value="<?= esc($alumnos['fecha_registro']) ?>">
                </div>
                <div class="mb-3 w-100">
                    <label for="tipo_actividad" class="form-label text-white">Tipo de Actividad</label>
                    <select id="tipo_actividad" name="tipo_actividad" class="form-select" required>
                        <option value="0">Elija actividad</option>
                        <?php foreach ($actividades as $actividad): ?>
                            <option value="<?= esc($actividad['id']) ?>" <?= $actividad['id'] == $alumnos['tipo_actividad'] ? 'selected' : '' ?>>
                                <?= esc($actividad['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3 w-100">
                    <label for="observacion" class="form-label text-white">Observaciones</label>
                    <textarea id="observacion" name="observacion" class="form-control" rows="4"><?= esc($alumnos['observaciones']) ?></textarea>
                </div>
                <div class="d-flex justify-content-between w-100">
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    <a href="<?= site_url('alumnos') ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </form>
        </div>
    </div>

    <footer style="background-color: black; color: white; font-weight: bold; text-align: center; padding: 10px; margin-top: 20px;">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>