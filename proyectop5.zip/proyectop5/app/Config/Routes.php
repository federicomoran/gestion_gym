<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('login', 'LoginController::index');         // Ruta para cargar la vista de login
$routes->post('login/autenticar', 'LoginController::autenticar'); // Ruta para manejar la autenticación
$routes->get('login/logout', 'LoginController::logout');
$routes->get('menu', 'MenuController::index');            // Ruta para cargar el menú después del login (ajusta el controlador si es necesario)
$routes->get('usuarios', 'UsuariosController::index');
$routes->get('usuarios/create', 'UsuariosController::create');
$routes->post('usuarios/store', 'UsuariosController::store');
$routes->get('usuarios/edit/(:num)', 'UsuariosController::edit/$1');
$routes->post('usuarios/update/(:num)', 'UsuariosController::update/$1');
$routes->get('usuarios/delete/(:num)', 'UsuariosController::delete/$1');
$routes->get('/alumnos', 'AlumnoController::index');
$routes->get('/alumnos/create', 'AlumnoController::create');
$routes->post('/alumnos/store', 'AlumnoController::store');
$routes->get('/alumnos/edit/(:num)', 'AlumnoController::edit/$1');
$routes->post('/alumnos/update/(:num)', 'AlumnoController::update/$1');
$routes->get('/alumnos/delete/(:num)', 'AlumnoController::delete/$1');
$routes->get('/tipo_actividad', 'TipoActividadController::index');
$routes->get('/tipo_actividad/create', 'TipoActividadController::create');
$routes->post('/tipo_actividad/store', 'TipoActividadController::store');
$routes->get('/tipo_actividad/edit/(:num)', 'TipoActividadController::edit/$1');
$routes->post('/tipo_actividad/update/(:num)', 'TipoActividadController::update/$1');
$routes->get('/tipo_actividad/delete/(:num)', 'TipoActividadController::delete/$1');
$routes->get('/rutinas', 'RutinaController::index');
$routes->get('/rutinas/generico', 'RutinaController::generico');
$routes->get('/rutinas/create', 'RutinaController::create');
$routes->get('/rutinas/create_generico', 'RutinaController::create_generico');
$routes->post('/rutinas/store_generico', 'RutinaController::store_generico');
$routes->post('/rutinas/store', 'RutinaController::store');
$routes->get('/rutinas/edit/(:num)', 'RutinaController::edit/$1');
$routes->post('/rutinas/update/(:num)', 'RutinaController::update/$1');
$routes->get('/rutinas/delete/(:num)', 'RutinaController::delete/$1');
$routes->get('/rutinas/edit_generico/(:num)', 'RutinaController::edit_generico/$1');
$routes->post('/rutinas/update_generico/(:num)', 'RutinaController::update_generico/$1');
$routes->get('/rutinas/delete_generico/(:num)', 'RutinaController::delete_generico/$1');
$routes->get('/turnos', 'TurnoController::index');
$routes->get('/turnos/create', 'TurnoController::create');
$routes->post('/turnos/store', 'TurnoController::store');
$routes->get('/turnos/edit/(:num)', 'TurnoController::edit/$1');
$routes->post('/turnos/update/(:num)', 'TurnoController::update/$1');
$routes->get('/turnos/delete/(:num)', 'TurnoController::delete/$1');
$routes->get('imc', 'ImcController::index');
$routes->get('imc/create', 'ImcController::create');
$routes->post('imc/store', 'ImcController::store');
$routes->get('imc/edit/(:num)', 'ImcController::edit/$1');
$routes->post('imc/update/(:num)', 'ImcController::update/$1');
$routes->get('imc/delete/(:num)', 'ImcController::delete/$1');
$routes->get('/instructores', 'InstructorController::index');
$routes->get('/instructores/create', 'InstructorController::create');
$routes->post('/instructores/store', 'InstructorController::store');
$routes->get('/instructores/edit/(:num)', 'InstructorController::edit/$1');
$routes->post('/instructores/update/(:num)', 'InstructorController::update/$1');
$routes->get('/instructores/delete/(:num)', 'InstructorController::delete/$1');
$routes->get('membresias', 'MembresiaController::index'); 
$routes->get('membresias/create', 'MembresiaController::create'); 
$routes->post('membresias/store', 'MembresiaController::store'); 
$routes->get('membresias/edit/(:num)', 'MembresiaController::edit/$1'); 
$routes->post('membresias/update/(:num)', 'MembresiaController::update/$1'); 
$routes->get('membresias/delete/(:num)', 'MembresiaController::delete/$1'); 
$routes->get('membresias/descuento_clases', 'MembresiaController::descuento_clases');
$routes->post('membresias/descontar_clase', 'MembresiaController::descontar_clase');

// Añadir esta línea para la ruta de visualización de archivos PDF
$routes->get('view/(:any)', 'ViewController::view/$1');
