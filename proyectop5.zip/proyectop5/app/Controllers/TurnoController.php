<?php

namespace App\Controllers;

use App\Models\TurnoModel;
use App\Models\TipoActividadModel;
use App\Models\InstructorModel;
use CodeIgniter\Controller;

class TurnoController extends Controller
{
    public function __construct()
    {
        $this->turnoModel = new TurnoModel();
    }

    public function index()
    {
        $model = new TurnoModel();
        $data['turnos'] = $model->getTurnos();
        return view('turnos/list', $data);
    }

    public function create()
    {
        $tipoActividadModel = new TipoActividadModel();
        $instructorModel = new InstructorModel();

        $data['actividades'] = $tipoActividadModel->findAll();
        $data['instructores'] = $instructorModel->findAll();

        return view('turnos/create', $data);
    }

    public function store()
    {
        $validation = $this->validate([
            'tipo_actividad' => 'required|integer',
            'instructor'     => 'required|integer',
            'horario'        => 'required'
        ]);

        if (!$validation) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        if ($this->turnoModel->save([
            'tipo_actividad' => $this->request->getPost('tipo_actividad'),
            'instructor'     => $this->request->getPost('instructor'),
            'horario'        => $this->request->getPost('horario'),
        ])) {
            echo "<script>
            alert('El turno ha sido agregado correctamente.');
            window.location.href='" . site_url('turnos') . "';
        </script>";
        } else {
            echo "<script>
            alert('No se pudo agregar el turno. Intente de nuevo.');
            window.location.href='" . site_url('turnos/create') . "';
        </script>";
        }
    }



    public function edit($id)
    {
        $model = new TurnoModel();
        $data['turno'] = $model->find($id);

        $tipoActividadModel = new TipoActividadModel();
        $instructorModel = new InstructorModel();

        $data['actividades'] = $tipoActividadModel->findAll();
        $data['instructores'] = $instructorModel->findAll();

        return view('turnos/edit', $data);
    }

    public function update($id)
    {
        $model = new TurnoModel();
        $data = [
            'tipo_actividad' => $this->request->getPost('tipo_actividad'),
            'instructor' => $this->request->getPost('instructor'),
            'horario' => $this->request->getPost('horario'),
        ];

        if ($model->update($id, $data)) {
            return redirect()->to('/turnos')->with('success', 'Turno actualizado exitosamente.');
        } else {
            return redirect()->back()->with('errors', $model->errors());
        }
    }

    public function delete($id)
    {
        $model = new TurnoModel();
        if ($model->delete($id)) {
            return redirect()->to('/turnos')->with('success', 'Turno eliminado exitosamente.');
        } else {
            return redirect()->back()->with('errors', 'No se pudo eliminar el turno.');
        }
    }
}
