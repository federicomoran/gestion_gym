<?php

namespace App\Controllers;

use App\Models\InstructorModel;
use App\Models\RutinaModel;

class InstructorController extends BaseController
{
    protected $instructorModel;
    protected $rutinaModel;

    public function __construct()
    {
        $this->instructorModel = new InstructorModel();
        $this->rutinaModel = new RutinaModel();
    }

    public function index()
    {
        $instructores = $this->instructorModel->select('instructores.*, rutinas.titulo as rutina_titulo')
            ->join('rutinas', 'rutinas.id = instructores.rutina')
            ->findAll();

        return view('instructores/list', [
            'instructores' => $instructores
        ]);
    }

    public function create()
    {
        $rutinas = $this->rutinaModel->findAll();
        return view('instructores/create', ['rutinas' => $rutinas]);
    }

    public function store()
    {
        if ($this->request->getMethod() === 'post') {
            $data = $this->request->getPost();

            $validation = \Config\Services::validation();

            $validation->setRules([
                'nombre' => 'required|min_length[3]|max_length[50]',
                'apellido' => 'required|min_length[3]|max_length[50]',
                'telefono' => 'required|numeric',
                'mail' => 'required|valid_email|is_unique[instructores.mail]',
                'rutina' => 'required|is_not_unique[rutinas.id]'
            ]);

            if (!$validation->run($data)) {
                return view('instructores/create', [
                    'validation' => $validation,
                    'rutinas' => $this->rutinaModel->findAll()
                ]);
            }

            if ($this->instructorModel->save($data)) {
                echo "<script>
        alert('Se ha registrado exitosamente el instructor.');
        window.location.href='" . site_url('instructores') . "';
        </script>";
                return;
            } else {
                echo "<script>
        alert('No se pudo crear el nuevo registro. Intente de nuevo.');
        window.location.href='" . site_url('instructor/create') . "';
        </script>";
                return;
            }
        }
    }


    public function edit($id)
    {
        $instructor = $this->instructorModel->find($id);
        if (!$instructor) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Instructor no encontrado.');
        }

        return view('instructores/edit', [
            'instructor' => $instructor,
            'rutinas' => $this->rutinaModel->findAll()
        ]);
    }

    public function update($id)
    {
        $instructor = $this->instructorModel->find($id);
        if (!$instructor) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Instructor no encontrado.');
        }

        $validation =  \Config\Services::validation();

        $validation->setRule('mail', 'Correo', 'required|valid_email|is_unique[instructores.mail,id,' . $id . ']');

        if ($this->request->getMethod() === 'post') {
            $data = $this->request->getPost();

            if ($validation->run($data)) {
                if ($this->instructorModel->update($id, $data)) {
                    return redirect()->to('/instructores')->with('success', 'Instructor actualizado con éxito');
                } else {
                    return redirect()->back()->with('error', 'No se pudo actualizar el instructor, verifique sus datos cargados.');
                }
            } else {
                return view('instructores/edit', [
                    'instructor' => $instructor,
                    'validation' => $validation,
                    'rutinas' => $this->rutinaModel->findAll()
                ]);
            }
        }

        return view('instructores/edit', [
            'instructor' => $instructor,
            'rutinas' => $this->rutinaModel->findAll()
        ]);
    }


    public function delete($id)
    {
        $instructor = $this->instructorModel->find($id);
        if (!$instructor) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Instructor no encontrado.');
        }

        if ($this->instructorModel->delete($id)) {
            return redirect()->to('/instructores')->with('success', 'Instructor eliminado con éxito');
        } else {
            return redirect()->back()->with('error', 'No se pudo eliminar el instructor.');
        }
    }
}
