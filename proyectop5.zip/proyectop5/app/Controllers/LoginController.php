<?php

namespace App\Controllers;

use App\Models\UsuarioModel;

class LoginController extends BaseController
{
    public function index()
    {
        return view('login'); // El nombre de tu vista de login
    }

    public function autenticar()
    {
        $session = session();
        $model = new UsuarioModel();

        // Obtén los datos del formulario
        $usuario = $this->request->getPost('usuario');
        $clave = $this->request->getPost('pass');

        // Depuración
        error_log("Usuario ingresado: $usuario");
        error_log("Contraseña ingresada: $clave");

        // Busca el usuario en la base de datos
        $datosUsuario = $model->where('usuario', $usuario)->first();

        // Log de los datos del usuario recuperado
        error_log("Datos del usuario desde la DB: " . print_r($datosUsuario, true));

        if ($datosUsuario) {
            // Verifica si la contraseña es correcta
            if ($clave === $datosUsuario['pass']) {
                // Configurar la sesión del usuario
                $sessionData = [
                    'id' => $datosUsuario['id'],           // Asumiendo que 'id' es el identificador del usuario
                    'nombre' => $datosUsuario['nombre'],
                    'apellido' => $datosUsuario['apellido'],
                    'usuario' => $datosUsuario['usuario'],
                    'isLoggedIn' => true,
                ];
                $session->set($sessionData);

                // Redirige al usuario a la página principal
                return redirect()->to('/menu');
            } else {
                // Contraseña incorrecta
                $session->setFlashdata('error', 'Contraseña incorrecta.');
                return redirect()->back();
            }
        } else {
            // Usuario no encontrado
            $session->setFlashdata('error', 'Usuario no encontrado.');
            return redirect()->back();
        }
    }

    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/login');
    }
}
