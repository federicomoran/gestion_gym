<?php

namespace App\Controllers;

use App\Models\MembresiaModel;
use App\Models\TipoActividadModel;
use App\Models\TurnoModel;
use App\Models\AlumnoModel;

class MembresiaController extends BaseController
{
    protected $membresiaModel;

    public function __construct()
    {
        $this->membresiaModel = new MembresiaModel();
    }

    public function index()
    {
        $this->membresiaModel->actualizarEstadoMembresias();

        $data['membresias'] = $this->membresiaModel
            ->select('membresias.*, alumnos.dni AS alumno_dni, tipo_actividad.nombre AS tipo_nombre, turnos.horario AS turno_horario')
            ->join('alumnos', 'alumnos.id = membresias.alumno', 'left')
            ->join('tipo_actividad', 'tipo_actividad.id = membresias.tipo_actividad', 'left')
            ->join('turnos', 'turnos.id = membresias.turnos', 'left')
            ->findAll();

        return view('membresias/list', $data);
    }

    public function create()
    {
        $tipoActividadModel = new TipoActividadModel();
        $turnoModel = new TurnoModel();
        $alumnoModel = new AlumnoModel();
        $data['tipo_actividades'] = $tipoActividadModel->findAll();
        $data['turnos'] = $turnoModel->findAll();
        $data['alumnos'] = $alumnoModel->findAll();
        return view('membresias/create', $data);
    }

    public function store()
    {
        $alumnoId = $this->request->getPost('alumno');
        $membresiaActiva = $this->membresiaModel->where('alumno', $alumnoId)
            ->where('estado', 'activo')
            ->first();

        if ($membresiaActiva) {
            return redirect()->to('/membresias')->with('error', 'El alumno ya tiene una membresía activa. No puede inscribirse en una nueva.');
        }

        $fechaAlta = date('Y-m-d', strtotime($this->request->getPost('fecha_alta')));
        $fechaBaja = date('Y-m-d', strtotime($this->request->getPost('fecha_baja')));

        if ($this->validate($this->membresiaModel->getValidationRules())) {
            $this->membresiaModel->save([
                'tipo_actividad' => $this->request->getPost('tipo_actividad'),
                'alumno' => $alumnoId,
                'precio' => $this->request->getPost('precio'),
                'clases' => $this->request->getPost('clases'),
                'fecha_alta' => $fechaAlta,
                'fecha_baja' => $fechaBaja,
                'turnos' => $this->request->getPost('turnos'),
                'estado' => $this->request->getPost('estado'),
            ]);

            echo "<script>
                alert('Membresía creada exitosamente.');
                window.location.href='" . site_url('membresias') . "';
            </script>";
        } else {
            echo "<script>
                alert('No se pudo crear la Membresía, verifique sus datos.');
                window.location.href='" . site_url('membresias/create') . "';
            </script>";
        }
    }

    public function edit($id)
    {
        $tipoActividadModel = new TipoActividadModel();
        $turnoModel = new TurnoModel();
        $alumnoModel = new AlumnoModel();
        $data['membresia'] = $this->membresiaModel->find($id);
        $data['tipo_actividades'] = $tipoActividadModel->findAll();
        $data['turnos'] = $turnoModel->findAll();
        $data['alumnos'] = $alumnoModel->findAll();
        return view('membresias/edit', $data);
    }

    public function update($id)
    {
        $membresiaActual = $this->membresiaModel->find($id);
        $nuevoAlumnoId = $this->request->getPost('alumno');
        $membresiaActiva = $this->membresiaModel->where('alumno', $nuevoAlumnoId)
            ->where('estado', 'activo')
            ->first();

        if ($membresiaActiva && $membresiaActiva['id'] !== $id) {
            return redirect()->to('/membresias')->with('error', 'No se puede cambiar a un alumno que ya tiene una membresía activa.');
        }

        $fechaAlta = date('Y-m-d', strtotime($this->request->getPost('fecha_alta')));
        $fechaBaja = date('Y-m-d', strtotime($this->request->getPost('fecha_baja')));

        if ($this->validate($this->membresiaModel->getValidationRules())) {
            $data = [
                'tipo_actividad' => $this->request->getPost('tipo_actividad'),
                'alumno' => $nuevoAlumnoId,
                'precio' => $this->request->getPost('precio'),
                'clases' => $this->request->getPost('clases'),
                'fecha_alta' => $fechaAlta,
                'fecha_baja' => $fechaBaja,
                'turnos' => $this->request->getPost('turnos'),
                'estado' => $this->request->getPost('estado'),
            ];
            $this->membresiaModel->update($id, $data);
            return redirect()->to('/membresias')->with('success', 'Membresía actualizada con éxito.');
        } else {
            return redirect()->to('/membresias')->with('validation', $this->validator);
        }
    }

    public function delete($id)
    {
        if ($this->membresiaModel->delete($id)) {
            return redirect()->to('/membresias')->with('success', 'Membresía eliminada correctamente.');
        } else {
            return redirect()->to('/membresias')->with('error', 'No se pudo eliminar la membresía.');
        }
    }

    public function descuento_clases()
    {
        return view('membresias/descuento_clases');
    }

    public function descontar_clase()
    {
        $dni = $this->request->getPost('dni');

        if (!preg_match('/^\d+$/', $dni)) {
            return redirect()->to('/membresias')->with('error', 'El DNI solo debe contener números, inténtelo nuevamente.')->withInput();
        }

        $alumnoModel = new AlumnoModel();
        $alumno = $alumnoModel->where('dni', $dni)->first();

        if (!$alumno) {
            return redirect()->to('/membresias')->with('error', 'Este DNI es inexistente o no está registrado en ninguna membresía.')->withInput();
        }

        $membresia = $this->membresiaModel->getMembresiaPorAlumno($alumno['id']);

        if ($membresia && $membresia['clases'] > 0 && $membresia['clases'] !== 'Pase Libre') {
            $nuevasClases = $membresia['clases'] - 1;

            $this->membresiaModel->update($membresia['id'], [
                'clases' => $nuevasClases
            ]);

            if ($nuevasClases <= 0) {
                $this->membresiaModel->update($membresia['id'], [
                    'estado' => 'Inactivo'
                ]);
            }

            return redirect()->to('/membresias')->with('success', 'Clase descontada correctamente.');
        } else {
            return redirect()->to('/membresias')->with('error', 'No se puede descontar clases. Verifique la membresía del alumno.')->withInput();
        }
    }
}
