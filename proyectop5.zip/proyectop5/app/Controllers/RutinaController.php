<?php

namespace App\Controllers;

use App\Models\RutinaModel;
use App\Models\AlumnoModel;
use App\Models\TipoActividadModel;

class RutinaController extends BaseController
{
    // Mostrar rutinas personalizadas (con alumnos)
    public function index()
    {
        $model = new RutinaModel();
        $data['rutinas'] = $model->obtenerRutinasPersonalizadas(); // Obtener rutinas personalizadas
        return view('rutinas/index', $data); // Vista para rutinas personalizadas
    }

    // Mostrar rutinas genéricas (sin alumnos)
    public function generico()
    {
        $model = new RutinaModel();
        $data['rutinas'] = $model->obtenerRutinasGenericas(); // Obtener rutinas genéricas
        return view('rutinas/generico', $data); // Vista para rutinas genéricas
    }

    // Formulario para crear rutina personalizada
    public function create()
    {
        $actividadModel = new TipoActividadModel();
        $data["actividades"] = $actividadModel->listarActividades();

        $alumnoModel = new AlumnoModel();
        $data["alumnos"] = $alumnoModel->listarAlumnos();

        return view('rutinas/create', $data);
    }

    // Guardar rutina personalizada
    public function store()
    {
        $model = new RutinaModel();

        // Obtener los datos del formulario
        $alumno = $this->request->getVar('alumno');
        $tipo_actividad = $this->request->getVar('tipo_actividad');

        // Verificar si el alumno ya está registrado con alguna rutina
        $done = $model->where('alumno', $alumno)->first();
        if ($done) {
            echo "<script>
        alert('Este alumno ya tiene una rutina registrada.');
        window.location.href='" . site_url('rutinas/create') . "';</script>";
            return;
        }

        // Validación del archivo
        $validationRule = [
            'archivo' => [
                'label'  => 'Archivo',
                'rules'  => 'uploaded[archivo]|ext_in[archivo,pdf,doc,docx]|max_size[archivo,2048]',
                'errors' => [
                    'uploaded' => 'Debes seleccionar un archivo.',
                    'ext_in'   => 'El archivo debe ser PDF, DOC o DOCX.',
                    'max_size' => 'El archivo no debe exceder los 2048KB.',
                ],
            ],
        ];

        if (!$this->validate($validationRule)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $file = $this->request->getFile('archivo');
        $originalName = $file->getClientName();
        $timestamp = time(); // Marca de tiempo
        $newFileName = $timestamp . '_' . $originalName; // Nuevo nombre del archivo

        $file->move(WRITEPATH . 'uploads', $newFileName); // Mover archivo

        // Guardar los datos de la rutina
        $data = [
            'alumno' => $alumno,
            'tipo_actividad' => $tipo_actividad,
            'titulo' => $this->request->getVar('titulo'),
            'descripcion' => $this->request->getVar('descripcion'),
            'archivo' => $newFileName,
        ];

        if ($model->insert($data)) {
            echo "<script>
        alert('Rutina creada correctamente.');
        window.location.href='" . site_url('rutinas') . "';</script>";
            return;
        } else {
            echo "<script>
        alert('Hubo un problema al guardar los datos. Intente de nuevo.');
        window.location.href='" . site_url('rutinas/create') . "';</script>";
            return;
        }
    }



    // Formulario para crear rutina genérica
    public function create_generico()
    {
        $actividadModel = new TipoActividadModel();
        $data["actividades"] = $actividadModel->listarActividades();

        return view('rutinas/create_generico', $data);
    }

    // Guardar rutina genérica
    public function store_generico()
    {
        $model = new RutinaModel();

        $validationRule = [
            'archivo' => [
                'label'  => 'Archivo',
                'rules'  => 'uploaded[archivo]|ext_in[archivo,pdf,doc,docx]|max_size[archivo,2048]',
                'errors' => [
                    'uploaded' => 'Debes seleccionar un archivo.',
                    'ext_in'   => 'El archivo debe ser PDF, DOC o DOCX.',
                    'max_size' => 'El archivo no debe exceder los 2048KB.',
                ],
            ],
        ];

        if (!$this->validate($validationRule)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $file = $this->request->getFile('archivo');
        $originalName = $file->getClientName();
        $timestamp = time(); // Marca de tiempo
        $newFileName = $timestamp . '_' . $originalName; // Nuevo nombre del archivo

        $file->move(WRITEPATH . 'uploads', $newFileName); // Mover archivo

        // Guardar los datos de la rutina
        $data = [
            'tipo_actividad' => $this->request->getVar('tipo_actividad'),
            'titulo' => $this->request->getVar('titulo'),
            'descripcion' => $this->request->getVar('descripcion'),
            'archivo' => $newFileName,
        ];

        if ($model->save($data)) {
            echo "<script>
        alert('Se ha registrado exitosamente la rutina.');
        window.location.href='" . site_url('rutinas/generico') . "';
        </script>";
            return;
        } else {
            echo "<script>
        alert('No se pudo crear el nuevo registro. Intente de nuevo.');
        window.location.href='" . site_url('rutinas/create_generico') . "';
        </script>";
            return;
        }
    }




    // Editar una rutina
    public function edit($id)
    {
        $rutinaModel = new RutinaModel();
        $alumnoModel = new AlumnoModel();
        $actividadModel = new TipoActividadModel();

        $data['rutina'] = $rutinaModel->find($id);
        $data['alumnos'] = $alumnoModel->findAll();
        $data['actividades'] = $actividadModel->listarActividades();

        return view('rutinas/edit', $data);
    }

    // Actualizar una rutina
    public function update($id)
    {
        $rutinaModel = new RutinaModel();

        // Validación del archivo
        $validationRule = [
            'archivo' => [
                'label'  => 'Archivo',
                'rules'  => 'uploaded[archivo]|ext_in[archivo,pdf,doc,docx]|max_size[archivo,2048]',
                'errors' => [
                    'uploaded' => 'Debes seleccionar un archivo.',
                    'ext_in'   => 'El archivo debe ser PDF, DOC o DOCX.',
                    'max_size' => 'El archivo no debe exceder los 2048KB.',
                ],
            ],
        ];

        if (!$this->validate($validationRule)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Manejo del archivo
        $file = $this->request->getFile('archivo');
        $newFileName = '';

        if ($file->isValid() && !$file->hasMoved()) {
            $newFileName = $file->getRandomName(); // Generar un nuevo nombre para el archivo
            $file->move(WRITEPATH . 'uploads', $newFileName); // Mover el archivo a la carpeta de uploads

            // Mensaje de depuración
            echo "Archivo movido a: " . WRITEPATH . 'uploads/' . $newFileName;
        }

        $rutinaData = [
            'alumno' => $this->request->getVar('alumno'),
            'tipo_actividad' => $this->request->getVar('tipo_actividad'),
            'titulo' => $this->request->getVar('titulo'),
            'descripcion' => $this->request->getVar('descripcion'),
            'archivo' => $newFileName, // Asignar el nombre del archivo al campo correspondiente
        ];

        $rutinaModel->skipValidation(true);

        if ($rutinaModel->update($id, $rutinaData)) {
            echo "<script>
            alert('Rutina editada correctamente.');
            window.location.href='" . site_url('rutinas') . "';
        </script>";
            return;
        } else {
            echo "<script>
            alert('Hubo un problema al guardar los datos. Intente de nuevo.');
            window.location.href='" . site_url('rutinas/edit/' . $id) . "';
        </script>";
            return;
        }
    }

    // Eliminar una rutina
    public function delete($id)
    {
        $model = new RutinaModel();
        $model->delete($id);
        return redirect()->to('/rutinas');
    }

    public function edit_generico($id)
    {
        $rutinaModel = new RutinaModel();
        $actividadModel = new TipoActividadModel();

        $data['rutina'] = $rutinaModel->find($id);
        $data['actividades'] = $actividadModel->listarActividades();

        return view('rutinas/edit_generico', $data);
    }

    // Método para actualizar una rutina genérica
    public function update_generico($id)
    {
        $rutinaModel = new RutinaModel();

        // Validación del archivo
        $validationRule = [
            'archivo' => [
                'label'  => 'Archivo',
                'rules'  => 'uploaded[archivo]|ext_in[archivo,pdf,doc,docx]|max_size[archivo,2048]',
                'errors' => [
                    'uploaded' => 'Debes seleccionar un archivo.',
                    'ext_in'   => 'El archivo debe ser PDF, DOC o DOCX.',
                    'max_size' => 'El archivo no debe exceder los 2048KB.',
                ],
            ],
        ];

        if (!$this->validate($validationRule)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Manejo del archivo
        $file = $this->request->getFile('archivo');
        $newFileName = '';

        if ($file->isValid() && !$file->hasMoved()) {
            $newFileName = $file->getRandomName(); // Generar un nuevo nombre para el archivo
            $file->move(WRITEPATH . 'uploads', $newFileName); // Mover el archivo a la carpeta de uploads

            // Mensaje de depuración
            echo "Archivo movido a: " . WRITEPATH . 'uploads/' . $newFileName;
        }

        $rutinaData = [
            'tipo_actividad' => $this->request->getVar('tipo_actividad'),
            'titulo' => $this->request->getVar('titulo'),
            'descripcion' => $this->request->getVar('descripcion'),
            'archivo' => $newFileName, // Asignar el nombre del archivo al campo correspondiente
        ];

        $rutinaModel->skipValidation(true);

        if ($rutinaModel->update($id, $rutinaData)) {
            echo "<script>
            alert('Rutina editada correctamente.');
            window.location.href='" . site_url('rutinas/generico') . "';
        </script>";
            return;
        } else {
            echo "<script>
            alert('Hubo un problema al guardar los datos. Intente de nuevo.');
            window.location.href='" . site_url('rutinas/edit_generico/' . $id) . "';
        </script>";
            return;
        }
    }

    // Método para eliminar una rutina genérica
    public function delete_generico($id)
    {
        $rutinaModel = new RutinaModel();

        if ($rutinaModel->delete($id)) {
            return redirect()->to('/rutinas/generico')->with('success', 'Rutina genérica eliminada correctamente.');
        } else {
            return redirect()->back()->with('error', 'Hubo un problema al eliminar la rutina genérica.');
        }
    }
}
