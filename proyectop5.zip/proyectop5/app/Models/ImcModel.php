<?php

namespace App\Models;

use CodeIgniter\Model;

class ImcModel extends Model
{
    protected $table = 'imc';
    protected $primaryKey = 'id';

    protected $allowedFields = ['alumno', 'peso', 'altura', 'calculo', 'fecha_calculo', 'fecha_modificacion'];
    protected $validationRules = [
        'alumno' => 'required',
        'peso' => 'required|integer', // Ajuste aquí
        'altura' => 'required|decimal', // Ajuste aquí
        'calculo' => 'required|decimal', // Ajuste aquí
        'fecha_calculo' => 'required|valid_date', // Ajuste aquí
        'fecha_modificacion' => 'permit_empty|valid_date' // Ajuste aquí
    ];

    public function obtenerAlumnos()
    {
        return $this->select('imc.*, alumnos.nombre as alumno_nombre, alumnos.apellido as alumno_apellido')
            ->join('alumnos', 'alumnos.id = imc.alumno', 'left')
            ->where('alumno IS NOT NULL')
            ->orderBy('fecha_calculo', 'DESC') // Ordenar por la fecha de cálculo más reciente
            ->findAll();
    }
}
