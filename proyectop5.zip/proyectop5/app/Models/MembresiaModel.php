<?php

namespace App\Models;

use CodeIgniter\Model;

class MembresiaModel extends Model
{
    protected $table = 'membresias';
    protected $primaryKey = 'id';

    protected $allowedFields = ['tipo_actividad', 'alumno', 'precio', 'clases', 'fecha_alta', 'fecha_baja', 'turnos', 'estado'];

    protected $validationRules = [
        'tipo_actividad' => 'required|is_not_unique[tipo_actividad.id]',
        'alumno' => 'required|is_not_unique[alumnos.id]',
        'precio' => 'required|numeric',
        'clases' => 'required',
        'fecha_alta' => 'required',
        'fecha_baja' => 'required',
        'turnos' => 'required|is_not_unique[turnos.id]',
        'estado' => 'required',
    ];

    public function getMembresiaPorAlumno($alumno_id)
    {
        return $this->where('alumno', $alumno_id)->first();
    }

    public function actualizarEstadoMembresias()
    {
        $fechaActual = date('Y-m-d');

        $membresias = $this->where('clases', 'Pase Libre')
            ->where('estado', 'Activo')
            ->where('fecha_baja <=', $fechaActual)
            ->findAll();

        foreach ($membresias as $membresia) {
            $this->update($membresia['id'], ['estado' => 'Inactivo']);
        }
    }
}
